configuration InstallTools
{
  Import-DscResource -ModuleName cChoco

  cChocoInstaller choco
  {
    InstallDir = 'C:\choco'
  }

    $chocoPackages = @('visualstudio2013ultimate')                          
    foreach($chocoPackage in $chocoPackages)
    {
        cChocoPackageInstaller $chocoPackage
        {
            Name = $chocoPackage
        }
    }

  Environment chocolatelyInstall
  {
    Name = 'chocolatelyInstall'
    value = 'C:\choco\bin'
  } 
}

InstallTools -OutputPath $env:temp\InstallTools
Start-DscConfiguration -Wait -Verbose -Path $env:temp\InstallTools